package dev.sadia.focustrail;
import org.junit.Test;
import static org.junit.Assert.*;
public class SessionRulesTest {
    @Test public void duration() { assertEquals(1500000,SessionRules.duration("25")); }
    @Test public void boundaries() { assertEquals(60000,SessionRules.duration("1")); assertEquals(10800000,SessionRules.duration("180")); }
    @Test(expected=IllegalArgumentException.class) public void zero() { SessionRules.duration("0"); }
    @Test(expected=IllegalArgumentException.class) public void large() { SessionRules.duration("181"); }
    @Test(expected=IllegalArgumentException.class) public void decimal() { SessionRules.duration("1.5"); }
    @Test public void trimTopic() { assertEquals("AI",SessionRules.topic(" AI ")); }
    @Test(expected=IllegalArgumentException.class) public void emptyTopic() { SessionRules.topic(" "); }
    @Test public void running() { assertEquals(500,SessionRules.remaining(1000,200,100,400,true)); }
    @Test public void paused() { assertEquals(800,SessionRules.remaining(1000,200,100,400,false)); }
    @Test public void expired() { assertEquals(0,SessionRules.remaining(1000,200,100,10000,true)); }
    @Test public void backwardClock() { assertEquals(800,SessionRules.remaining(1000,200,400,100,true)); }
    @Test public void display() { assertEquals("00:01",SessionRules.clock(1)); assertEquals("25:00",SessionRules.clock(1500000)); }
}
