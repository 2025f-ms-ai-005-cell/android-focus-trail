package dev.sadia.focustrail;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;

/** Foreground study timer. No alarms or background notification claims. */
public final class MainActivity extends Activity {
    private SharedPreferences prefs;
    private JSONArray history = new JSONArray();
    private String topic = "";
    private long total, accumulated, started;
    private boolean running, writable = true;
    private TextView timer, status, progress;
    private EditText topicInput, minutes;
    private LinearLayout historyList;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        public void run() { render(); handler.postDelayed(this, 500); }
    };

    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("focus", MODE_PRIVATE);
        try { history = new JSONArray(prefs.getString("history", "[]")); }
        catch (Exception e) { writable=false; }
        if (state != null) {
            topic=state.getString("topic", ""); total=state.getLong("total"); accumulated=state.getLong("accumulated");
            started=state.getLong("started"); running=state.getBoolean("running");
        }
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,40,28,24); root.setBackgroundColor(Color.rgb(12,24,39));
        TextView title=text("FocusTrail",32); root.addView(title); root.addView(text("STUDY SESSIONS • OFFLINE",12));
        progress=text("",18); root.addView(progress);
        topicInput=new EditText(this); topicInput.setHint("Study topic"); topicInput.setTextColor(Color.WHITE); topicInput.setHintTextColor(Color.LTGRAY); topicInput.setSingleLine(true); root.addView(topicInput);
        minutes=new EditText(this); minutes.setHint("Minutes (1–180)"); minutes.setText("25"); minutes.setTextColor(Color.WHITE); minutes.setInputType(2); root.addView(minutes);
        timer=text("25:00",48); timer.setGravity(17); root.addView(timer);
        status=text("Ready for a focused session",16); root.addView(status);
        LinearLayout actions=new LinearLayout(this);
        button(actions,"Start",this::start); button(actions,"Pause / Resume",this::toggle); root.addView(actions);
        Button end=new Button(this); end.setText("End session"); end.setOnClickListener(v -> {
            if(total==0)return;
            new AlertDialog.Builder(this).setTitle("End this session?").setMessage("Save elapsed study time as an ended session?").setNegativeButton("Keep studying",null).setPositiveButton("Save",(d,w)->finishSession(false)).show();
        }); root.addView(end);
        root.addView(text("SESSION HISTORY",14)); historyList=new LinearLayout(this); historyList.setOrientation(1);
        ScrollView scroll=new ScrollView(this); scroll.addView(historyList); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); renderHistory(); render();
        if(!writable) new AlertDialog.Builder(this).setTitle("History needs recovery").setMessage("Stored history could not be read. It has not been overwritten; new sessions cannot be saved.").setPositiveButton("OK",null).show();
        if(state==null && prefs.contains("activeTopic")) {
            topic=prefs.getString("activeTopic",""); total=prefs.getLong("activeTotal",0); accumulated=prefs.getLong("activeElapsed",0); running=false;
            toast("Recovered paused session; background time was not counted"); render();
        }
    }
    private TextView text(String value,int size) { TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setPadding(0,12,0,12); return t; }
    private void button(LinearLayout parent,String label,Runnable action) { Button b=new Button(this); b.setText(label); b.setOnClickListener(v->action.run()); parent.addView(b,new LinearLayout.LayoutParams(0,-2,1)); }
    private long remaining() { return SessionRules.remaining(total,accumulated,started,SystemClock.elapsedRealtime(),running); }
    private void start() {
        if(total>0) { toast("End the current session first"); return; }
        if(!writable) { toast("History requires recovery"); return; }
        try { topic=SessionRules.topic(topicInput.getText().toString()); total=SessionRules.duration(minutes.getText().toString()); accumulated=0; started=SystemClock.elapsedRealtime(); running=true; checkpoint(); render(); }
        catch(IllegalArgumentException e) { toast(e.getMessage()); }
    }
    private void toggle() {
        if(total==0)return;
        if(running) { accumulated=total-remaining(); running=false; }
        else { started=SystemClock.elapsedRealtime(); running=true; }
        checkpoint(); render();
    }
    private void checkpoint() {
        if(!writable)return;
        SharedPreferences.Editor e=prefs.edit();
        if(total==0)e.remove("activeTopic").remove("activeTotal").remove("activeElapsed");
        else e.putString("activeTopic",topic).putLong("activeTotal",total).putLong("activeElapsed",total-remaining());
        if(!e.commit()) toast("Session checkpoint could not be saved");
    }
    private void finishSession(boolean completed) {
        long elapsed=total-remaining();
        try {
            JSONArray next=new JSONArray(history.toString());
            next.put(new JSONObject().put("topic",topic).put("date",LocalDate.now().toString()).put("elapsed",elapsed).put("completed",completed));
            while(next.length()>200) next.remove(0);
            if(!writable || !prefs.edit().putString("history",next.toString()).remove("activeTopic").remove("activeTotal").remove("activeElapsed").commit()) {
                accumulated=elapsed; running=false; toast("Save failed; session retained paused for retry"); return;
            }
            history=next; running=false; total=0; accumulated=0; renderHistory();
        } catch(Exception e) { running=false; accumulated=elapsed; toast("Unable to save session; retry End session"); }
    }
    private void render() {
        long left=remaining();
        if(total>0 && running && left==0)finishSession(true);
        timer.setText(total==0?"Ready":SessionRules.clock(remaining()));
        status.setText(total==0?"Start a new study session":topic+(running?" • focusing":" • paused"));
        topicInput.setEnabled(total==0); minutes.setEnabled(total==0);
    }
    private void renderHistory() {
        historyList.removeAllViews(); long today=0; int completed=0;
        for(int i=history.length()-1;i>=0;i--) {
            JSONObject s=history.optJSONObject(i); if(s==null)continue;
            if(LocalDate.now().toString().equals(s.optString("date"))) { today+=s.optLong("elapsed"); if(s.optBoolean("completed"))completed++; }
            historyList.addView(text(s.optString("topic")+"\n"+s.optString("date")+" • "+SessionRules.clock(s.optLong("elapsed"))+(s.optBoolean("completed")?" • completed":" • ended"),16));
        }
        if(history.length()==0)historyList.addView(text("No saved sessions yet",16));
        progress.setText("Today: "+(today/60000)+" min • "+completed+" completed");
    }
    protected void onResume() { super.onResume(); handler.post(tick); }
    protected void onPause() {
        super.onPause(); handler.removeCallbacks(tick);
        if(running) { accumulated=total-remaining(); running=false; }
        checkpoint();
    }
    protected void onSaveInstanceState(Bundle s) { s.putString("topic",topic); s.putLong("total",total); s.putLong("accumulated",total-remaining()); s.putLong("started",SystemClock.elapsedRealtime()); s.putBoolean("running",running); super.onSaveInstanceState(s); }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
}
