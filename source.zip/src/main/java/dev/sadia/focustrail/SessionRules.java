package dev.sadia.focustrail;

/** Pure session rules, separate from Android and persistence. */
public final class SessionRules {
    private SessionRules() {}
    public static long duration(String minutes) {
        try {
            int value = Integer.parseInt(minutes.trim());
            if (value < 1 || value > 180) throw new IllegalArgumentException();
            return value * 60_000L;
        } catch (RuntimeException e) { throw new IllegalArgumentException("Choose 1–180 whole minutes"); }
    }
    public static String topic(String value) {
        String text = value.trim();
        if (text.isEmpty() || text.length() > 80) throw new IllegalArgumentException("Topic must be 1–80 characters");
        return text;
    }
    public static long remaining(long total, long accumulated, long start, long now, boolean running) {
        long elapsed = running ? Math.max(0, now - start) : 0;
        return Math.max(0, total - Math.min(total, accumulated) - Math.min(total, elapsed));
    }
    public static String clock(long ms) {
        long seconds = Math.max(0, ms + 999) / 1000;
        return String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
    }
}
