plugins { id("com.android.application") version "8.13.2" }
android {
    namespace = "dev.sadia.focustrail"
    compileSdk = 35
    defaultConfig { applicationId = "dev.sadia.focustrail"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { testImplementation("junit:junit:4.13.2") }
